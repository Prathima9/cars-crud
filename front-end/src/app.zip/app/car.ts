export class Car {
  id: number;
  builddate: string;
  make: string;
  model: string;
  color: string;
  numberofdoors: string;
  enginesie: string;
 
}
